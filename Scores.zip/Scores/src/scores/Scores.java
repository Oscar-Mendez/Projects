/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scores;
import java.security.SecureRandom;
import java.util.Arrays;

/**
 *
 * @author oscarmendez
 */
public class Scores {

    public int Scores[];
    
    public Scores(){
        SecureRandom num = new SecureRandom();
        Scores = new int[10];
        
        for(int i = 0; i < Scores.length; i++){
            Scores[i] = num.nextInt(100);
        }
        
    }
    
    
    public int[] getScores(){
    
        return Scores;
    }
    
    public String toString(){
        return String.format("%s %s %s %s %s %s %s %s %s %s %n",
                Scores[0], Scores[1], Scores[2], Scores[3], Scores[4],
                Scores[5], Scores[6], Scores[7], Scores[8], Scores[9]);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scores;

/**
 *
 * @author oscarmendez
 */
public class TestScores {
    
    public static void main(String[] Args){
        
        Scores value = new Scores();
        LetterGrades letters = new LetterGrades();
        
        //int[] array = value.getScores();
        
        //for(int i = 1; i < array.length; i++){
            System.out.printf("%s%n" , value.toString());
            
            System.out.printf("%s%n", letters.toString());
        //}
        
        
        
    }
}

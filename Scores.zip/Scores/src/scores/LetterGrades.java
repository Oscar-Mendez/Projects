/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scores;

/**
 *
 * @author oscarmendez
 */
public class LetterGrades extends Scores{
    
    
    private char[] lgrades;
    
    public LetterGrades(){
        super();
        lgrades = new char[10];
        
        for(int i = 0; i < 10; i++) {
            if(Scores[i] >= 90){
                lgrades[i] = 'A';
            }
            else if (Scores[i] >= 80 && Scores[i] < 90){
                lgrades[i] = 'B';
            }
             else if (Scores[i] >= 70 && Scores[i] < 80){
                lgrades[i] = 'C';
            }
            else if (Scores[i] >= 60 && Scores[i] < 70){
                lgrades[i] = 'D';
            }
            else if(Scores[i] < 60){
                lgrades[i] = 'F';
            }
        }
        
    }
    
    public char[] getLetters(){
    
        return lgrades;
    }
    
    @Override
    public String toString(){
        return String.format(" %s: %c%n %s: %c%n %s: %c%n %s: %c%n %s: %c%n %s: %c%n"
                + " %s: %c%n %s: %c%n %s: %c%n %s: %c%n", Scores[0],lgrades[0], Scores[1],
                lgrades[1],Scores[2], lgrades[2],Scores[3],lgrades[3],
                Scores[4], lgrades[4],
                Scores[5], lgrades[5], Scores[6], lgrades[6], Scores[7], 
                lgrades[7], Scores[8], lgrades[8], Scores[9], lgrades[9]);
    }
    
    
}
